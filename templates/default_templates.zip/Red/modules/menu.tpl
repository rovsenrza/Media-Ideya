<ul>
	<li class="parent"><a href="/lastnews">{{Our News}}<svg class="icon icon-arrow_down"><use xlink:href="#icon-arrow_down"></use></svg></a>
		{catmenu}
	</li>
	<li class="parent"><a href="/index.php?do=feedback">{{Support}}<svg class="icon icon-arrow_down"><use xlink:href="#icon-arrow_down"></use></svg></a>
		<ul>
			<li><a rel="nofollow" target="_blank" href="https://{{website_url}}/">{{Developers Website}}</a></li>
			<li><a rel="nofollow" target="_blank" href="https://{{website_url}}/lastnews/">{{Blog}}</a></li>
			<li><a rel="nofollow" target="_blank" href="https://{{website_url}}/faq.html">{{FAQ}}</a></li>
			<li><a rel="nofollow" target="_blank" href="https://{{website_url}}/price.html">{{Buy Engine}}</a></li>
		</ul>
	</li>
	<li class="parent"><a href="#">{{Customers}}<svg class="icon icon-arrow_down"><use xlink:href="#icon-arrow_down"></use></svg></a>
		<ul>
			<li><a href="/rules.html">{{Rules}}</a></li>
			<li><a href="/index.php?do=register">{{Registration}}</a></li>
			<li><a href="/statistics.html">{{Statistics}}</a></li>
		</ul>
	</li>
	<li class="parent block_archives"><a href="#">{{Archive}}<svg class="icon icon-arrow_down"><use xlink:href="#icon-arrow_down"></use></svg></a>
		<div>
			<div>
				<ul class="arh_tabs">
					<li class="active">
						<a title="{{Calendar}}" href="#arch_calendar" aria-controls="arch_calendar" data-toggle="tab">
							{{Calendar}}
						</a>
					</li>
					<li>
						<a title="{{Archive}}" href="#arch_list" aria-controls="arch_list" data-toggle="tab">
							{{Archive}}
						</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="arch_calendar">{calendar}</div>
					<div class="tab-pane" id="arch_list">
						{archives}
					</div>
				</div>
			</div>
		</div>
	</li>
</ul>