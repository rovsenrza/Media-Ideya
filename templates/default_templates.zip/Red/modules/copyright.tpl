<div class="foot grey">
	<div class="copyright grid_1_2">
		Copyright © 2004&ndash;2026 <a href="https://{{website_url}}/" target="_blank"><b>SoftNews Media Group</b></a> All Rights Reserved.<br>Powered by DataLife Engine © 2026
	</div>
	<a class="ca" href="http://centroarts.ru" target="_blank" rel="nofollow" title="Дизайн Centroarts">
		<span><svg class="icon icon-ca"><use xlink:href="#icon-ca"></use></svg></span>
		<div>Design <b>Centroarts</b></div>
	</a>
	<ul class="counters">
		<li>
			{changeskin}
		</li>
	</ul>
</div>