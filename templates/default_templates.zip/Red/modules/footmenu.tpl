<ul class="foot_menu">
	<li class="grid_1_4">
		<b data-toggle="collapse" data-target="#fmenu_1" aria-expanded="false" class="ultrabold collapsed">
			<i></i> {{Our News}}
		</b>
		<div class="collapse" id="fmenu_1">
			<nav>
				<a href="#">{{Special report}}</a>
				<a href="#">{{Strategy}}</a>
				<a href="#">{{Insurance}}</a>
				<a href="#">{{Territory}}</a>
				<a href="#">{{Transport}}</a>
			</nav>
		</div>
	</li>
	<li class="grid_1_4">
		<b data-toggle="collapse" data-target="#fmenu_2" aria-expanded="false" class="ultrabold collapsed">
			<i></i> {{Support}}
		</b>
		<div class="collapse" id="fmenu_2">
			<nav>
				<a href="https://{{website_url}}/" target="_blank">{{Developers Website}}</a>
				<a href="https://forum.dle-news.ru/" target="_blank">{{Support forum}}</a>
				<a href="https://{{website_url}}/lastnews/" target="_blank">{{Blog}}</a>
				<a href="https://{{website_url}}/price.html" target="_blank">{{Buy Engine}}</a>
			</nav>
		</div>
	</li>
	<li class="grid_1_4">
		<b data-toggle="collapse" data-target="#fmenu_3" aria-expanded="false" class="ultrabold collapsed">
			<i></i> {{Customers}}
		</b>
		<div class="collapse" id="fmenu_3">
			<nav>
				<a href="/">{{Homepage}}</a>
				<a href="/index.php?do=feedback">{{Contacts}}</a>
				<a href="/rules.html">{{Rules}}</a>
				<a href="/index.php?do=register">{{Registration}}</a>
				<a href="/statistics.html">{{Statistics}}</a>
			</nav>
		</div>
	</li>
	<li class="grid_1_4 grid_last">
		<b data-toggle="collapse" data-target="#fmenu_4" aria-expanded="false" class="ultrabold collapsed">
			<i></i> {{We in the social networks}}
		</b>
		<div class="collapse" id="fmenu_4">
			<nav>
				<a href="#" target="_blank" rel="nofollow">Facebook</a>
				<a href="#" target="_blank" rel="nofollow">Twitter</a>
				<a href="#" target="_blank" rel="nofollow">Instagram</a>
			</nav>
		</div>
	</li>
</ul>