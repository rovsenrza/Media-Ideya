<ul class="foot_menu">
	<li>
		<b data-toggle="collapse" data-target="#fmenu_1" aria-expanded="false" class="collapsed">
			<i></i>{{Our News}}
		</b>
		<div class="collapse" id="fmenu_1">
			<nav>
				<a href="#">{{Special report}}</a>
				<a href="#">{{Strategy}}</a>
				<a href="#">{{Insurance}}</a>
				<a href="#">{{Territory}}</a>
				<a href="#">{{Technology housing}}</a>
				<a href="#">{{Transport}}</a>
			</nav>
		</div>
	</li>
	<li>
		<b data-toggle="collapse" data-target="#fmenu_2" aria-expanded="false" class="collapsed">
			<i></i> {{Articles}}
		</b>
		<div class="collapse" id="fmenu_2">
			<nav>
				<a href="#">{{Facts}}</a>
				<a href="#">{{Financial strategy}}</a>
				<a href="#">{{Legislative power}}</a>
				<a href="#">{{The Church}}</a>
				<a href="#">{{Detective}}</a>
				<a href="#">{{Economy}}</a>
			</nav>
		</div>
	</li>
	<li>
		<b data-toggle="collapse" data-target="#fmenu_3" aria-expanded="false" class="collapsed">
			<i></i> {{Customers}}
		</b>
		<div class="collapse" id="fmenu_3">
			<nav>
				<a href="/">{{Homepage}}</a>
				<a href="/statistics.html">{{Statistics}}</a>
				<a href="/lastnews/">{{Latest news}}</a>
				<a href="/index.php?do=lastcomments">{{Latest comments}}</a>
				<a href="/index.php?do=register">{{Registration}}</a>
				<a href="/index.php?do=feedback">{{Contacts}}</a>
			</nav>
		</div>
	</li>
	<li>
		<b data-toggle="collapse" data-target="#fmenu_4" aria-expanded="false" class="collapsed">
			<i></i> {{Support}}
		</b>
		<div class="collapse" id="fmenu_4">
			<nav>
				<a href="https://{{website_url}}/" target="_blank" rel="nofollow">{{Developers Website}}</a>
				<a href="https://forum.dle-news.ru/" target="_blank" rel="nofollow">{{Support forum}}</a>
				<a href="https://{{website_url}}/lastnews/" target="_blank" rel="nofollow">{{Blog}}</a>
				<a href="https://{{website_url}}/faq.html" target="_blank" rel="nofollow">{{FAQ}}</a>
				<a href="https://{{website_url}}/price.html" target="_blank" rel="nofollow">{{Buy Engine}}</a>
			</nav>
		</div>
	</li>
	<li>
		<b data-toggle="collapse" data-target="#fmenu_5" aria-expanded="false" class="collapsed">
			<i></i> {{Customers}}
		</b>
		<div class="collapse" id="fmenu_5">
			<nav>
				<a href="/">{{Homepage}}</a>
				<a href="/index.php?do=feedback">{{Contacts}}</a>
				<a href="/rules.html">{{Rules}}</a>
				<a href="/index.php?do=register">{{Registration}}</a>
				<a href="/statistics.html">{{Statistics}}</a>
			</nav>
		</div>
	</li>
</ul>