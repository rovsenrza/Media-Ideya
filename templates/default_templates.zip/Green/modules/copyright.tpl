<div class="footer grey">
	<div class="copyright">
		Copyright © 2004&ndash;2026 <a href="https://{{website_url}}/" target="_blank">SoftNews Media Group</a> All Rights Reserved.<br>Powered by DataLife Engine © 2026
	</div>
	<a class="ca" href="http://centroarts.ru" target="_blank" rel="nofollow">
		<span><svg class="icon icon-ca"><use xlink:href="#icon-ca"></use></svg></span>
		<div>Design <b>Centroarts</b></div>
	</a>
</div>