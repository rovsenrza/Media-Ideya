<div class="foot grey">
	<div class="soc_links">
		<b class="title">{{We in the social networks}}</b>
		<a href="#" target="_blank" rel="nofollow" class="soc_vk" title="{{We vKontakte}}">
			<svg class="icon icon-tw">
				<use xlink:href="#icon-tw" />
			</svg>
		</a>
		<a href="#" target="_blank" rel="nofollow" class="soc_tw" title="{{We Twitter}}">
			<svg class="icon icon-tw"><use xlink:href="#icon-tw"/></svg>
		</a>
		<a href="#" target="_blank" rel="nofollow" class="soc_fb" title="{{We Facebook}}">
			<svg class="icon icon-fb"><use xlink:href="#icon-fb"/></svg>
		</a>
	</div>
	<ul class="counters">
		<li>
			<img src="{THEME}/images/tmp/counter.png" alt="">
		</li>
		<li>
			<img src="{THEME}/images/tmp/counter.png" alt="">
		</li>
		<li>
			<img src="{THEME}/images/tmp/counter.png" alt="">
		</li>
	</ul>
</div>