<article class="block story searchpage">
	<h1 class="title h2">{{Search site}}</h1>
	<div id="searchtable" name="searchtable" class="searchtable">{searchtable}</div>
	[searchmsg]<div class="search_result_num grey">{searchmsg}</div>[/searchmsg]
</article>