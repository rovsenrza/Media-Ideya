<div id="comid-{comment-id}" class="comment vcard">
	<div class="mass-check">{mass-action}</div>
	<div class="com-cont clrfix">
		{comment}
	</div>
	<div class="com-inf">
		<img class="photo" src="{foto}" alt="{login}">
		<b class="arg fn">[profile]{login}[/profile]</b>
		<span class="arg">{date}</span>
		<span class="fast">[fast]<b class="thd">{{Quote}}</b>[/fast]</span>
		<span class="del">[com-del]<b class="thd">{{Delete}}</b>[/com-del]</span>
	</div>
</div>