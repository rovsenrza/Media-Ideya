<!DOCTYPE html>
<html>
<head>
{headers}
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="{THEME}/css/engine{{rtl_prefix}}.css" rel="stylesheet">
<link href="{THEME}/css/styles{{rtl_prefix}}.css" rel="stylesheet">
<script src="{THEME}/js/libs.js" defer></script>
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
</head>
<body>
	{AJAX}
	<div id="toolbar">
		<div id="in-toolbar">
			{login}
			<a id="menu-btn">
				<span id="hamburger"></span>
			</a>
		</div>
		<!-- Head Menu -->
		<nav id="menu-head">
			<a href="#">{{Special report}}е</a>
			<a href="#">{{Strategy}}</a>
			<a href="#">{{Insurance}}</a>
			<a href="#">{{Territory}}</a>
			<a href="#">{{Technology housing}}</a>
			<a href="#">{{Transport}}</a>
			<a href="#">{{Facts}}</a>
			<a href="#">{{Financial strategy}}</a>
		</nav>
		<!-- Head Menu [E] -->
	</div>
	<div class="background"></div>
	<header id="header">
		<!-- LogoType -->
		<a id="logo" href="/">
			<b id="logo-text">Datalife Engine</b>
			<span>Softnews Media Group</span>
		</a>
		<!-- LogoType [E] -->
		<!--Search-->
		<form id="quicksearch" method="post" action=''>
			<input type="hidden" name="do" value="search">
			<input type="hidden" name="subaction" value="search">
			<div class="quicksearch">
				<input class="f_input" placeholder="{{Search...}}" name="story" value="" type="search">
				<button type="submit" class="thd">{{Find}}</button>
			</div>
		</form>
		<!--Search [E]-->
		<a id="go2full" class="ico" href="/index.php?action=mobiledisable">{{Full version of the site}}</a>
	</header>
	<section id="content">
		{info}
		{content}
	</section>
	<div id="footmenu">
		<h3>{{Navigation}}</h3>
		<nav class="main-nav">
			<a href="#">{{Special report}}е</a>
			<a href="#">{{Strategy}}</a>
			<a href="#">{{Insurance}}</a>
			<a href="#">{{Territory}}</a>
			<a href="#">{{Technology housing}}</a>
			<a href="#">{{Transport}}</a>
			<a href="#">{{Facts}}</a>
			<a href="#">{{Financial strategy}}</a>
			<span class="nav-sep"></span>
			<a href="/index.php?do=lastnews" target="_blank">{{Our News}}</a>
			<a href="https://{{website_url}}/" target="_blank">{{Developers Website}}</a>
			<a href="/index.php?action=mobiledisable">{{Full version of the site}}</a>
		</nav>
	</div>
	<footer id="footer">
		<div class="background"></div>
		<div id="copyright">Powered by <a href="https://{{website_url}}/" target="_blank">DataLife Engine</a> © 2026</div>
	</footer>
</body>
</html>