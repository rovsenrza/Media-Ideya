<div class="pager clrfix">
	{{Pages}}: {pages}
</div>