<div class="pager clrfix">
	[prev-link]<b class="pprev ico">{{Previous Page}}</b>[/prev-link]
	[next-link]<b class="pnext ico">{{Next Page}}</b>[/next-link]
</div>