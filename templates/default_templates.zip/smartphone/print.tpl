<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body,td { font-family: verdana, arial, sans-serif; color: #666; font-size: 80%; }
        h1,h2,h3,h4 { font-family: verdana, arial, sans-serif; color: #666; font-size: 100%; margin: 0px; }
        img {border:0}
    </style>
    <title>{{Homepage}} > {{Printable version}} > {title}</title>
</head>
<body bgcolor="#ffffff" text="#000000">
    <table border="0" width="100%" cellspacing="1" cellpadding="3">
        <tr>
            <td width="100%">
                <a href="/">{{Homepage}}</a> > {category} > [full-link]{title}[/full-link]
                <hr>
                <h1>{title}</h1><br><small>{date}. {{Author}}: {author}</small>
            </td>
        </tr>
        <tr>
            <td width="100%">
                {full-story}
                <hr>
                <a href="javascript:history.go(-1)">{{Go back}}</a>
            </td>
        </tr>
    </table>
</body>

</html>